import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Text(
                  "Rumah Makan Sedap Rasa",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 20),
              Center(child: Image.asset('assets/images/bakso.jpeg')),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Icon(
                    Icons.email,
                    color: Colors.black,
                  ),
                  Icon(
                    Icons.phone,
                    color: Colors.black,
                  ),
                  Icon(
                    Icons.person,
                    color: Colors.black,
                  ),
                ],
              ),
              SizedBox(height: 20),
              Text(
                "Deskripsi:",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolores unde atque, dignissimos fugiat, quas est sequi odit ipsam nisi dolorum dolore minus illum! Eaque officiis dolores, quibusdam voluptatibus architecto amet?",
              ),
              SizedBox(height: 20),
              Text(
                "List Menu:",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(8),
                  children: <Widget>[
                    Container(
                      height: 50,
                      color: Colors.amber,
                      margin: EdgeInsets.only(bottom: 10),
                      child: const Center(
                        child: Text(
                          'Soto',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    Container(
                      height: 50,
                      color: Colors.amber,
                      margin: EdgeInsets.only(bottom: 10),
                      child: const Center(
                        child: Text(
                          'Bakso',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Text(
                "Alamat:",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text("Jalan imam bonjol Semarang Jawa Tengah"),
              SizedBox(height: 20),
              Text(
                "Jam Buka:",
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text("Setiap hari jam 08:00 - 10:00 WIB")
            ],
          ),
        ),
      )),
    );
  }
}
