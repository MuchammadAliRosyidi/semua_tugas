import 'package:flutter/material.dart';

const header1 = TextStyle(fontWeight: FontWeight.bold, fontSize: 28);
const header2 = TextStyle(fontWeight: FontWeight.bold, fontSize: 23);
const header3 = TextStyle(fontWeight: FontWeight.bold, fontSize: 18);
const header4 = TextStyle(fontWeight: FontWeight.bold, fontSize: 12);
