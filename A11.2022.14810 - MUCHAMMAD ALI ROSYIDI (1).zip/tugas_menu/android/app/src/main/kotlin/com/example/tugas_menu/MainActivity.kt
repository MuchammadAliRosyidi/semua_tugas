package com.example.tugas_menu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
